﻿Cauchy model for Glass Substrate, with Surface Roughness
ALPHA_MULTILAYER

start_Model Version
	2	
end_Model Version

start_Model Parms
	2	0	
	0.0	F	-5.0	5.0	F	'Angle Offset'	F	F	0.0	0.0	100000.0	F	100.0	
	F	
	114.62616711097938	T	-100.0	200.0	F	'Roughness'	F	F	0.0	0.0	100000.0	F	100.0	
	F	
	20	
	''	
	NaN	
	NaN	
	-1	
	
	''	
	NaN	
	NaN	
	-1	
	
	''	
	NaN	
	NaN	
	-1	
	
	F	
	5.0	F	0.0	20.0	F	'# Back Reflections'	F	F	0.0	0.0	100000.0	F	100.0	
	100.0	F	0.0	100.0	F	'% 1st Reflection'	F	F	0.0	0.0	100000.0	F	100.0	
	
	F	
	3800.0	9000.0	
	F	
	'N,C,S'	
	F	
	F	
	20	
	0.0	F	0.0	50.0	F	'Bandwidth (eV)'	F	F	0.0	0.0	100000.0	F	100.0	
	9	
	F	
	T	
	F	
	F	
	5000.0	9000.0	
	F	
	5	
	F	
	F	
	'Ideal'	
	0.0	F	0.0	100.0	F	'% Thickness Non-uniformity'	F	F	0.0	0.0	100000.0	F	100.0	
	0.0	F	0.0	30.0	F	'Bandwidth (nm)'	F	F	0.0	0.0	100000.0	F	100.0	
	F	
	F	
	'All'	
	100.0	
	25	
	F	
	F	
	10.0	
	
	start_GlobalFit
		0	
		
	end_GlobalFit
	
	start_Ambient
		F	
		'(Not Specified)'	
		F	
		'(Not Specified)'	
		
	end_Ambient
	
	start_ScatteringFactor
		F	
		'(Not Specified)'	
		
	end_ScatteringFactor
	F	
	F	
	100.0	
	100.0	
	0.0	F	-5.0	5.0	F	'Wvl. Shift (nm)'	F	F	0.0	0.0	100000.0	F	100.0	
	1.0E-4	
	
	start_Simulation
		250.0	1000.0	5.0	45.0	75.0	10.0	100.0	F	0.5	
		F	
		1	
		0.0	F	0.0	10.0	F	'Angular Spread'	F	F	0.0	0.0	100000.0	F	100.0	
		'None'	
		0.0	F	-20.0	20.0	F	'#1'	F	F	0.0	0.0	100000.0	F	100.0	
		0.0	F	-20.0	20.0	F	'#2'	F	F	0.0	0.0	100000.0	F	100.0	
		0.0	F	-20.0	20.0	F	'#3'	F	F	0.0	0.0	100000.0	F	100.0	
		0.0	F	-20.0	20.0	F	'#4'	F	F	0.0	0.0	100000.0	F	100.0	
		0.0	F	-180.0	180.0	F	'Source Rot.'	F	F	0.0	0.0	100000.0	F	100.0	
		0.0	F	-180.0	180.0	F	'Receiver Rot.'	F	F	0.0	0.0	100000.0	F	100.0	
		F	0	
	end_Simulation
	
	start_MultiSamp
		0	0	
		
		start_DS Weighting
			
		end_DS Weighting
		
	end_MultiSamp
	
	start_ParmCoupling
		0	
		
		start_ParmCouplingFitParms
			0	
		end_ParmCouplingFitParms
		
	end_ParmCoupling
	100.0	
	'Standard Ellipsometric'	
	0	
	50	
	F	
	'(none)'	
	5	
	0.0	F	0.0	1000.0	F	'Smear Width'	F	F	0.0	0.0	100000.0	F	100.0	
	F	
	0	
	F	
	
	start_BW Conv
		'Gaussian'	
		0.0	F	0.0	1.0	F	'Exp. Relative Amp.'	F	F	0.0	0.0	100000.0	F	100.0	
		1.0	F	0.0	50.0	F	'Exp. Relative Width'	F	F	0.0	0.0	100000.0	F	100.0	
		F	
		0.0	F	0.0	30.0	F	'Bandwidth (nm) IR'	F	F	0.0	0.0	100000.0	F	100.0	
		1000.0	
		
	end_BW Conv
	
	start_Patterning
		F	
		0	
		0.0	F	0.0	100.0	F	'% Patterned'	F	F	0.0	0.0	100000.0	F	100.0	
		
	end_Patterning
	
	start_Color Calc
		F	
		0	0	0	0	
		0	1	2	'0'	
	end_Color Calc
	'(none)'	
	5	
	0.0	F	0.0	1000.0	F	'Smear Width #2'	F	F	0.0	0.0	100000.0	F	100.0	
	'(none)'	
	5	
	0.0	F	0.0	1000.0	F	'Smear Width #3'	F	F	0.0	0.0	100000.0	F	100.0	
	
	start_MultiModel
		0	2	
		
		50.0	F	0.0	100.0	F	'mWt1'	F	F	0.0	0.0	100000.0	F	100.0	
		50.0	F	0.0	100.0	F	'mWt2'	F	F	0.0	0.0	100000.0	F	100.0	
		
	end_MultiModel
	F	
	0.0	F	-20.0	20.0	F	'PsiOffset'	F	F	0.0	0.0	100000.0	F	100.0	
	0.0	F	-20.0	20.0	F	'PsiOff #1'	F	F	0.0	0.0	100000.0	F	100.0	
	0.0	F	-20.0	20.0	F	'PsiOff #2'	F	F	0.0	0.0	100000.0	F	100.0	
	0.0	F	-20.0	20.0	F	'PsiOff #3'	F	F	0.0	0.0	100000.0	F	100.0	
	0.0	F	-20.0	20.0	F	'PsiOff #4'	F	F	0.0	0.0	100000.0	F	100.0	
	
	start_LAB MSE
		F	
		
	end_LAB MSE
	
end_Model Parms

start_Derived Parms
	T	
	
end_Derived Parms

start_Derived Parms 2
	'n'	0	6328.0	0.0	0.0	F	F	5	
	
end_Derived Parms 2

start_Previous Results
	F	
	''	
	F	
	'-'	
	
end_Previous Results

start_Selected Options
	
	start_Options_Model Options
		F	
		F	
		F	
		F	
		F	
		F	
		F	
		F	
		F	
		F	
		F	
		F	
		F	
		F	
		
	end_Options_Model Options
	
	start_Options_Fit Options
		F	
		F	
		F	
		F	
		F	
		F	
		F	
		
	end_Options_Fit Options
	
	start_Options_Other Options
		F	
		F	
		F	
		
	end_Options_Other Options
	
end_Selected Options

start_Prefit Stage Options
	F	
	
	start_Prefit Fit Parms
		0	
	end_Prefit Fit Parms
	
	start_Prefit Global Parms
		F	
		3700.0	50000.0	
		5	
		100	
		F	
		'All'	
		F	
		'N,C,S'	
		0	
		50	
		
	end_Prefit Global Parms
	
end_Prefit Stage Options

start_First Point Only Options
	T	
	0	
	0	
	
end_First Point Only Options

start_Model Structure
	
	start_Layer0
		1.0E7	F	-0.0	1.0E8	F	'Substrate Thickness'	F	F	0.0	0.0	100000.0	F	100.0	
		'Layer'	'Cauchy Substrate'	'CAUCHY'	''	'Cauchy Substrate'	
		start_Cauchy Substrate Fit Parms
			2.0537052919861285	T	1.2	4.0	F	'A'	F	F	0.0	0.0	100000.0	F	100.0	
			-0.001	T	-0.001	0.5	F	'B'	F	F	0.0	0.0	100000.0	F	100.0	
			-0.001	T	-0.001	0.01	F	'C'	F	F	0.0	0.0	100000.0	F	100.0	
			0.0	F	0.0	10.0	F	'k Amplitude'	F	F	0.0	0.0	100000.0	F	100.0	
			1.5	F	0.0	10.0	F	'Exponent'	F	F	0.0	0.0	100000.0	F	100.0	
			4000.0	
			
		end_Cauchy Substrate Fit Parms
		
		start_SL Parms
			0	1	
			
		end_SL Parms
		
	end_Layer0
	
	start_Layer1
		666.2752102033212	T	200.0	1500.0	F	'Thickness # 1'	F	F	0.0	0.0	100000.0	F	100.0	
		'Layer'	'TIN 3 (Lorentz)'	'OSC'	''	'TIN 3 (Lorentz)'	
		start_TIN 3 (Lorentz) Fit Parms
			4	1.8077836701371635	T	0.0	10.0	F	'Einf'	F	F	0.0	0.0	100000.0	F	100.0	
			1.9202637038615515	T	0.0	1000.0	F	'Amp'	F	F	0.0	0.0	100000.0	F	100.0	
			1.6263403996356192	T	0.0	100.0	F	'Br'	F	F	0.0	0.0	100000.0	F	100.0	
			1.4560491722323756	T	1.0E-8	15.0	F	'En'	F	F	0.0	0.0	100000.0	F	100.0	
			100.51146155944475	T	0.0	1000.0	F	'Amp'	F	F	0.0	0.0	100000.0	F	100.0	
			4.812495637982255	T	0.0	100.0	F	'Br'	F	F	0.0	0.0	100000.0	F	100.0	
			5.22183381016502	T	1.0E-8	15.0	F	'En'	F	F	0.0	0.0	100000.0	F	100.0	
			170.65781770397342	T	0.0	1000.0	F	'Amp'	F	F	0.0	0.0	100000.0	F	100.0	
			44.79889927353972	T	0.0	100.0	F	'Br'	F	F	0.0	0.0	100000.0	F	100.0	
			1.0000297638327648E-8	T	1.0E-8	15.0	F	'En'	F	F	0.0	0.0	100000.0	F	100.0	
			3.758266166585825	T	0.0	1000.0	F	'Amp'	F	F	0.0	0.0	100000.0	F	100.0	
			0.8298084499011337	T	0.0	100.0	F	'Br'	F	F	0.0	0.0	100000.0	F	100.0	
			1.0273035767720686E-7	T	1.0E-8	15.0	F	'En'	F	F	0.0	0.0	100000.0	F	100.0	
			
		end_TIN 3 (Lorentz) Fit Parms
		
		start_SL Parms
			0	1	
			
		end_SL Parms
		
	end_Layer1
	
end_Model Structure
